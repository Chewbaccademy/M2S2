function PageCall(e,t){"undefined"!=typeof analytics&&(null!=t?analytics.page(e,t):analytics.page(e))}function TrackCall(e,t){"undefined"!=typeof analytics&&(null!=t?analytics.track(e,t):analytics.track(e))}"function"!=typeof Object.assign&&Object.defineProperty(Object,"assign",{value:function(e,t){"use strict"
if(null===e||void 0===e)throw new TypeError("Cannot convert undefined or null to object")
for(var n=Object(e),i=1;i<arguments.length;i++){var o=arguments[i]
if(null!==o&&void 0!==o)for(var a in o)Object.prototype.hasOwnProperty.call(o,a)&&(n[a]=o[a])}return n},writable:!0,configurable:!0})
var APP=APP||{}
APP.segmentConfig={cookieDomain:"livecareer.com",cookiePath:"/"}
var jsUtility={call_Ajax:function(e,t,n,i,o,a,r,s,l){var c
c=new XMLHttpRequest,c.onload=function(){4!=c.readyState||201!=c.status&&200!=c.status?l&&o&&o():o&&(a?o(c.responseText,a):o(c.responseText))},"GET"!=t||s||(e=-1==e.indexOf("?")?e+"?v="+(new Date).getTime():e+"&v="+(new Date).getTime()),c.open(t,e,n),i&&(c.withCredentials=!0),c.setRequestHeader("Content-Type","application/json;charset=UTF-8"),r?c.send(r):c.send(),c.onerror=function(e){l&&o&&o()},c.ontimeout=function(e){l&&o&&o()}},getHostURL:function(){if(false)return "https://www.livecareer.com/"
var e=document.domain.substring(0,document.domain.indexOf(".")),t=false
return-1==e.indexOf("iso")&&e.indexOf("-")>-1&&!t&&(e=e.split("-")[0]),"https://"+e+document.domain.slice(document.domain.indexOf(".")).replace(/\//g,"")+"/"},set_Cookie:function(e,t,n){var i=new Date
i.setDate(i.getDate()+n)
var o=escape(t)+(null==n?"":"; expires="+i.toUTCString()),a=document.domain.substring(document.domain.indexOf("."))
false&&(a="."+APP.segmentConfig.cookieDomain),document.cookie=a?e+"="+o+";domain="+a+";path=/":e+"="+o+";path=/"},get_Cookie:function(e){var t=document.cookie,n=t.indexOf(" "+e+"=")
if(-1==n&&(n=t.indexOf(e+"=")),-1==n)t=null
else{n=t.indexOf("=",n)+1
var i=t.indexOf(";",n);-1==i&&(i=t.length),t=unescape(t.substring(n,i))}return t},htmlEscape:function(e){if(e)return e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")},htmlUnescape:function(e){if(e)return e.replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"and")},getParameterByName:function(e){e=e.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]")
var t=new RegExp("[\\?&]"+e+"=([^&#]*)"),n=t.exec(location.search)
return null===n?"":decodeURIComponent(n[1].replace(/\+/g," "))},getCookieKeyValPair:function(e,t,n){var i="",o=jsUtility.get_Cookie(e)
if(null!=o&&o.length>0){var a=o.split(n)
if(a.length>0&&-1!=a[0].indexOf(":"))for(var r in a)if(-1!=a[r].split(":")[0].trim().indexOf(t)){i=a[r].split(":")[1].trim()
break}}return i},getDeviceType:function(){var e,t=jsUtility.get_Cookie("visitinfo")
if(t&&-1!==t.indexOf("DeviceType")){var n=t.indexOf("DeviceType")
e=t.substring(n).split("]&[")[0].split(",")[1].trim()}return e||(e=navigator.userAgent.match(/iPad|Tablet|PlayBook/i)?"tablet":navigator.userAgent.match(/Mobile|Android|webOS|iPhone|iPod|Blackberry/i)?"mobile":"desktop"),e},loadJs:function(e,t){var n,i
n=document.createElement("script"),n.type="text/javascript",n.src=e,n.async=null==t||void 0==t||t,i=document.getElementsByTagName("script")[0],i.parentNode.insertBefore(n,i)}},_segmentFirePageLoadEvent="undefined"!=typeof FIRE_PAGELOAD_EVENT&&FIRE_PAGELOAD_EVENT
false&&jsUtility.loadJs(jsUtility.getHostURL()+"blob/common/consent-manager/cookie-consent.min.js",!0)
var ManageFS=ManageFS||{}
ManageFS=function(e){var t=function(e,t){var n=[1e3,60,60,24],o=[e-t]
for(i=0;i<n.length;i++)o.push(parseInt(o[i]/n[i])),o[i]=o[i]%n[i]
return o[1]>30&&(o[2]=o[2]+1),o.reverse()}
e.updateSessionCount=function(){jsUtility.call_Ajax(jsUtility.getHostURL()+"c/fs/api/v1/fullstory/sessions/counter?update=true","POST",!0,!0,null,null,null,!0,!0)}
var n=function(){var n=jsUtility.get_Cookie("fs_user"),i=new Date((new Date).toUTCString()).getTime()
if(n&&0!=n){var o=t(i,n)
o&&o.length>2&&(o[0]>0||o[1]>0||o[2]>30)&&e.updateSessionCount()}jsUtility.set_Cookie("fs_user",i,3)}
return e.ManageInactivityTime=function(){n(),["mousedown","mousemove","keypress","scroll","touchstart"].forEach(function(e){document.addEventListener(e,n,!0)})},e.loadFullStory=function(){var e=0==integrations.All
if(window.segment){var t=window.segment
e=t.DisableFullStory||e&&!(t.Integrations&&t.Integrations.FullStory),t.ConsentIntegrations&&t.ConsentIntegrations.hasOwnProperty("FullStory")&&(e=e||!t.ConsentIntegrations.FullStory)}var n=jsUtility.get_Cookie("fs_user")
return!e&&"0"!=n&&(null!=n||null!=n&&void 0)},e}(ManageFS||{})
var writeKey="B7rLk975WsvRuE8E91XEVqzL3jn8HddD",segment_portal_name="LiveCareer",integrations={"All":false,"Mixpanel":true,"Segment.io":true}
"undefined"!=typeof SEGMENT_EVENTS_TO_ALL&&SEGMENT_EVENTS_TO_ALL&&(integrations={"Google Analytics":false, "FullStory":false}),APP.segment=function(e){var t=function(t){if(e.setMixpanelPropsCookie(0),"function"==typeof segmentReady&&!t)try{segmentReady()}catch(e){console.log(e)}_segmentFirePageLoadEvent&&TrackEvents("page")},n=function(e){var t={},n=JSON.parse(e)
return Object.keys(n).forEach(function(e,i){-1==e.indexOf("Experiment:")&&(t[e]=n[e])}),JSON.stringify(t)},i=function(e){var t={},n=["id","distinct_id","userId","Platform","device type","time"],i=JSON.parse(e)
return Object.keys(i).forEach(function(e,o){(0==e.indexOf("$")||0==e.indexOf("mp_")||0==e.indexOf("utm")||n.indexOf(e)>-1)&&(t[e]=i[e])}),JSON.stringify(t)}
return e.getGAId=function(){var e=null
try{var t=jsUtility.get_Cookie("_ga")
if(t&&t.trim().length>0){var n=t.split(".")
e=n[n.length-2]+"."+n[n.length-1]}}catch(e){console.log(e)}return e},e.setMixpanelPropsCookie=function(t){var o=""
try{if("undefined"!=typeof mixpanel&&void 0!==mixpanel.get_distinct_id){var a="desktop"
"function"==typeof jsUtility.getDeviceType&&(a=jsUtility.getDeviceType().toLowerCase()),mixpanel.register({"device type":a})
var r=mixpanel._.info.properties()
r.hasOwnProperty("$browser_version")&&(r.$browser_version=Math.floor(r.$browser_version)),r.hasOwnProperty("time")&&(r.time=Math.floor(r.time))
var s=mixpanel.persistence.properties()
o=JSON.stringify(Object.assign(r,s)),o.$current_url=location.href,o=n(o),o=i(o),jsUtility.set_Cookie("mixpanelprops",o)}else++t<20&&setTimeout(function(){e.setMixpanelPropsCookie(t)},100)}catch(e){console.log("error in mixpanel properties fetching")}},e.load=function(){var e=0==integrations.All
if(window.segment){var t=window.segment
e=t.DisableFullStory||e&&!(t.Integrations&&t.Integrations.FullStory),t.ConsentIntegrations&&t.ConsentIntegrations.hasOwnProperty("FullStory")&&(e=e||!t.ConsentIntegrations.FullStory)}var n=jsUtility.get_Cookie("fs_user")
if(e||"0"==n)APP.segment.loadAnalytics(!1)
else if(null!=n)APP.segment.loadAnalytics(!0)
else if(null==n){var i=Math.floor(100*Math.random()+1),o=i%parseFloat(20)
0==o?jsUtility.call_Ajax(jsUtility.getHostURL()+"c/fs/api/v1/fullstory/sessions/counter","POST",!0,!0,function(e){try{var t=JSON.parse(e).isNewSessionAllowed
t||jsUtility.set_Cookie("fs_user",0,1),APP.segment.loadAnalytics(t)}catch(e){jsUtility.set_Cookie("fs_user",0,1),APP.segment.loadAnalytics(!1)}},null,null,!0,!0):(jsUtility.set_Cookie("fs_user",0,1),APP.segment.loadAnalytics(!1))}},e.loadAnalytics=function(e){!function(){var n=window.analytics=window.analytics||[]
if(!n.initialize)if(n.invoked)window.console&&console.error&&console.error("Segment snippet included twice.")
else{n.invoked=!0,n.methods=["trackSubmit","trackClick","trackLink","trackForm","pageview","identify","reset","group","track","ready","alias","page","once","off","on"],n.factory=function(e){return function(){var t=Array.prototype.slice.call(arguments)
return t.unshift(e),n.push(t),n}}
for(var i=0;i<n.methods.length;i++){var o=n.methods[i]
n[o]=n.factory(o)}n.load=function(e,t){var i=document.createElement("script")
i.type="text/javascript",i.defer=!0,i.src=("https:"===document.location.protocol?"https://":"http://")+"cdn.segment.com/analytics.js/v1/"+e+"/analytics.min.js"
var o=document.getElementsByTagName("script")[0]
o.parentNode.insertBefore(i,o),n._loadOptions=t},n.SNIPPET_VERSION="4.1.0",1==e&&ManageFS.ManageInactivityTime()
var a=APP.segment.getIntegrationObject(!0)
if(a){var r={integrations:a}
n.load(writeKey,r)}else n.load(writeKey)
var s=!1
if("function"==typeof segmentReady)try{segmentReady(),s=!0}catch(o){console.log(o)}n.ready(t(s))}}()},e.getIntegrationObject=function(e){var t=Object.assign({},integrations)
if(window.segment&&window.segment.Integrations)if(t&&0!=t.All)for(var n in segment.Integrations)segment.Integrations[n]&&"all"!=n.toLowerCase()?t.hasOwnProperty(n)&&delete t[n]:n.length>0&&"all"!=n.toLowerCase()&&(t[n]=segment.Integrations[n])
else for(var n in segment.Integrations)segment.Integrations[n]||"all"==n.toLowerCase()?n.length>0&&"all"!=n.toLowerCase()&&(t[n]=segment.Integrations[n]):t.hasOwnProperty(n)&&delete t[n]
if(!e&&window.segment&&window.segment.ConsentIntegrations){var i=window.segment.ConsentIntegrations
if(t)if(0!=t.All)for(var n in i)i[n]&&t.hasOwnProperty(n)?t[n]=!0:0==i[n]&&(t[n]=i[n])
else for(var n in t)i.hasOwnProperty(n)&&(t[n]=i[n])}var o=ManageFS.loadFullStory()
return t&&(t.hasOwnProperty("FullStory")&&delete t.FullStory,0!=t.All?0==o&&(t.FullStory=!1):1==o&&(t.FullStory=!0)),t},e.getSegmentContext=function(e,t){return e&&void 0!==t&&void 0!==t.locale&&"undefined"!=typeof Storage&&localStorage.setItem("segment_context_locale",t.locale),localStorage.getItem("segment_context_locale")},e.getSegmentLocaleByUrl=function(){var e,t,n=window.location.pathname.split("/"),i=["lp","eb"]
return n[1]&&2==n[1].length&&!i.includes(n[1])&&(e=n[1]),n[2]&&2==n[2].length&&!i.includes(n[2])&&(t=n[2]),e&&t?t.toLowerCase()+"-"+e.toUpperCase():e&&!t?("nl"==e.toLowerCase()?t="nl":"dk"==e.toLowerCase()?t="da":"se"==e.toLowerCase()&&(t="sv"),t.toLowerCase()+"-"+e.toUpperCase()):""},e}(APP.segment||{}),false&&localStorage.setItem("segment_context_locale",APP.segment.getSegmentLocaleByUrl()),window.TrackEvents=function(e,t,n,i,o,a,r){var s=window.segment&&window.segment.CommonProps?JSON.parse(JSON.stringify(window.segment.CommonProps)):{}
i||(i=jsUtility.getCookieKeyValPair("UserStatus","IsUserLoggedIn",",")),s["Login Status"]=i&&"true"==i.toString().toLowerCase()?"TRUE":"FALSE",s.path=window.location.pathname,s.url=window.location.href
var l={}
if(t)for(var c in t)t[c]&&(s[c]=t[c],l[c]=t[c])
s.visitId=jsUtility.get_Cookie("vsuid"),s.Platform="Web",s.$screen_height=screen.height,s.$screen_width=screen.width,"function"==typeof jsUtility.getDeviceType&&(s["device type"]=jsUtility.getDeviceType().toLowerCase()),segment_portal_name&&(s.Portal=segment_portal_name)
var g=APP.segment.getSegmentContext(n,a)
switch(void 0!==g&&null!=g&&(s.locale=g),e){case"identify":FireSegmentIOIdentify(n,l,o,a)
break
case"page":var u=jsUtility.get_Cookie("vstrType")
s["Visitor Type"]=u?"Returning":"New",u||jsUtility.set_Cookie("vstrType",1,1825)
var d=APP.segment.getGAId()
d&&s&&d.length>0&&(s.GA_Id=d),FireSegmentIOPage("",s)
break
default:FireSegmentIOTrack(e,s,r)}APP.segment.setMixpanelPropsCookie(0)},window.TrackAlias=function(e){FireSegmentIOAlias(e)},window.FireSegmentIOIdentify=function(e,t,n,i){t=t||null
var o={}
null==t&&(t={})
var a=APP.segment.getSegmentContext(e,i)
if("undefined"!=typeof analytics){var r=APP.segment.getIntegrationObject()
e&&void 0!==a&&null!=a&&(t.locale=a),n&&(r.Iterable=!1),o.integrations=r,e?analytics.identify(e,t,o):analytics.identify(t,o),analytics.ready(function(){analytics.user().traits({})})}},window.FireSegmentIOPage=function(e,t){try{if(t=t||null,"undefined"!=typeof analytics){var n=APP.segment.getIntegrationObject()
null!=t?analytics.page(e,t,{integrations:n}):analytics.page(e,{IsPropsNull:!0},{integrations:n})}}catch(e){console.log(e)}},window.FireSegmentIOTrack=function(e,t,n){try{if(t=t||null,"undefined"!=typeof analytics){var i=APP.segment.getIntegrationObject()
null!=t?analytics.track(e,t,{integrations:i},n):analytics.track(e,{},{integrations:i},n)}else n&&n()}catch(e){console.log(e)}},window.FireSegmentIOAlias=function(e){try{"undefined"!=typeof analytics&&analytics.alias(e,{integrations:APP.segment.getIntegrationObject()})}catch(e){console.log(e)}},window.TrackUTMEvents=function(e){var t=jsUtility.getParameterByName("utm_source"),n=jsUtility.getParameterByName("utm_medium"),i=jsUtility.getParameterByName("utm_term"),o=jsUtility.getParameterByName("utm_content"),a=jsUtility.getParameterByName("utm_campaign"),r={"UTM Source first touch":t,"UTM Medium first touch":n,"UTM Term first touch":i,"UTM Content first touch":o,"UTM Campaign first touch":a},s={}
if(r)for(var l in r)r[l]&&(s[l]=r[l])
s||FireSegmentIOIdentify(e,s,!1,!0)},window.TrackPageEvents=function(e,t){TrackPageEventsFinal(e,t)},window.TrackPageEventsFinal=function(e,t){"undefined"!=typeof mixpanel&&void 0!==mixpanel.get_distinct_id&&jsUtility.set_Cookie("screenWidth",window.innerWidth)
var n={}
for(var i in e)e[i]&&(n[i]=e[i])
TrackEvents("page",n,null,t)},!true&&/Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)&&APP.segment.load()
